# ChatGPT

# VS Code AI 擴充套件適用比較

在受限網路環境中，我們針對各 AI 擴充套件進行評估，結果比較如下：

<table><tr><td>工具</td><td>需要登入</td><td>支援Proxy 設定</td><td>支援自訂 API端點</td><td>即時程式碼輔助 功能</td></tr><tr><td>GitHub Copilot</td><td>是(需 GitHub 帳戶) 1</td><td>支援(可透過 VS Code 設定 HTTP Proxy) 2</td><td>否 (無法切換到内部 Azure API)</td><td>是 (提供程式碼自 動完成和內嵌聊 天）</td></tr><tr><td>Continue</td><td>否 (開源免費)</td><td>支援 (使用VS Code 代 理設定） 3</td><td>是 (可設定自訂 Azure OpenAl端點) 4</td><td>是(有聊天介面和 即時補全) 5</td></tr><tr><td>Gemini Assist</td><td>是(需Google 帳戶） 6</td><td>否(Google服務被封 鎖)</td><td>否 (無自訂API 支援)</td><td>是 (提供聊天與自 動完成)</td></tr><tr><td>Cline</td><td>否 (開源免費) 7</td><td>支援(使用VS Code 代 理)</td><td>是(支援 OpenAl/Azure 等自訂) 8 1</td><td>是 (進階代理式編 輯和自動化) 9</td></tr><tr><td>Roo Code</td><td>否(可選擇雲 端登入） 10</td><td>支援 (可設定自訂 Base URL) 11</td><td>是(支援 Azure OpenAI / 其他兼容端點) 12 11</td><td>是(聊天式界面， 可跨多檔案讀寫) 13</td></tr></table>

推薦使用： Continue• $\blacktriangle$ Cline 與 Roo Code。三者皆為開源免費，不需強制登入即可使用，且支援設定內部 Azure OpenAI API 端點（可透過自訂 Base URL 或 OpenAI 相容配置接入內網模型） 4 。其12中 Continue 在本地運行、不需帳號，且提供即時聊天與內嵌程式碼補全 5 ；Cline 支援多種模型3供應商（包括 Azure OpenAI），執行於用戶端 8 ，適合不希望程式碼外傳的團隊；Roo Code 同7樣可設定自訂 API（包含 Azure 端點） 12 ，並以聊天方式讀寫多個檔案 。三者都能在受限網路11 13下經由公司 Proxy 存取內部模型，提供即時編程輔助。

不推薦使用： GitHub Copilot 及 Gemini Assist。Copilot 需登入 GitHub 帳號• ，且服務端通訊依賴1外部連線（難以設定為走內部 Azure），因此在此網路下無法正常使用（儘管支援 Proxy 設定 ）2 。Gemini 則需登入 Google 帳號 且連接 Google AI 服務，在被封鎖的網域環境下亦不可用。其他如6Microsoft 官方的 AI 擴充（如 AI Toolkit for VS Code 等）主要用於建構 AI 應用，通常需帳號且不聚焦於即時程式碼補全，本場景下可忽略。

參考資料： 如上表所示，持不同需求的工具特性都來自官方文件和說明 1 3 4 5 6 7 8 11 12。13 。

$^ 2$ Configuring network settings for GitHub Copilot - GitHub Docs https://docs.github.com/en/copilot/how-tos/configure-personal-settings/configure-network-settings

$^ 3$ FAQs - Continue https://docs.continue.dev/faqs

$4$ How to Configure Azure AI Foundry with Continue - Continue https://docs.continue.dev/customize/model-providers/top-level/azure

$5$ Continue - open-source AI code agent - Visual Studio Marketplace https://marketplace.visualstudio.com/items?itemName=Continue.continue

$6$ Code Gemini Assist : Un guide avec des exemples | DataCamp https://www.datacamp.com/fr/tutorial/gemini-code-assist

$^ { 7 } ~ 9$ Cline - AI Coding, Open Source and Uncompromised https://cline.bot

$^ 8$ Cline - Visual Studio Marketplace https://marketplace.visualstudio.com/items?itemName=saoudrizwan.claude-dev

Connecting Your First AI Provider | Roo Code Documentation10 https://docs.roocode.com/getting-started/connecting-api-provider

Using Anthropic With Roo Code | Roo Code Documentation11 https://docs.roocode.com/providers/anthropic

Roo Code 3.2.8 Release Notes | Roo Code Documentation12   
https://docs.roocode.com/update-notes/v3.2.8

The Chat Interface | Roo Code Documentation13 https://docs.roocode.com/basic-usage/the-chat-interface